#!/usr/bin/env bash
. stop_service.sh
. start_production.sh