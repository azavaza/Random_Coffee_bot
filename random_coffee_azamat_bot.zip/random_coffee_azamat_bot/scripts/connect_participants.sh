#!/usr/bin/env bash
export RANDOM_COFFEE_SETTINGS=development
python manage.py connect_participants --username random_coffee_development_bot -y 2019 -w 51
