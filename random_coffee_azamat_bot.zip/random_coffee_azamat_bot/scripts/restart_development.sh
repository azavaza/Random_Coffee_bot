#!/usr/bin/env bash
. stop_service.sh
. start_development.sh