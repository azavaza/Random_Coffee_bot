#!/usr/bin/env bash
cat pids | xargs kill -9
